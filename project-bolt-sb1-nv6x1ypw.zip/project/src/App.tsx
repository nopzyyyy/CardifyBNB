import { useState } from 'react';
import { ShoppingBag, Send, ArrowLeft } from 'lucide-react';

const giftCards = [
  { name: 'Uber', color: 'from-black to-gray-800' },
  { name: 'Walmart', color: 'from-blue-600 to-blue-800' },
  { name: 'Amazon', color: 'from-orange-500 to-yellow-600' },
  { name: 'eBay', color: 'from-red-600 to-yellow-500' },
  { name: 'Apple Pay', color: 'from-gray-800 to-black' },
];

function App() {
  const [showProducts, setShowProducts] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const handleShopNow = () => {
    setIsTransitioning(true);
    setTimeout(() => {
      setShowProducts(true);
      setIsTransitioning(false);
    }, 600);
  };

  const handleBackHome = () => {
    setIsTransitioning(true);
    setTimeout(() => {
      setShowProducts(false);
      setIsTransitioning(false);
    }, 600);
  };

  const handleBuyNow = () => {
    window.open('https://t.me/CardifyBNBOT', '_blank');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-black to-gray-900 text-white overflow-hidden relative">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-64 h-64 bg-yellow-500/10 rounded-full blur-3xl animate-glow"></div>
        <div className="absolute top-40 right-20 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl animate-glow" style={{ animationDelay: '1s' }}></div>
        <div className="absolute bottom-20 left-1/4 w-96 h-96 bg-yellow-600/10 rounded-full blur-3xl animate-glow" style={{ animationDelay: '2s' }}></div>
        <div className="absolute bottom-40 right-1/3 w-72 h-72 bg-amber-600/10 rounded-full blur-3xl animate-glow" style={{ animationDelay: '1.5s' }}></div>

        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:64px_64px]"></div>

        <div className="absolute top-1/4 left-1/4 w-20 h-20 animate-float opacity-20">
          <div className="w-full h-full rounded-full bg-gradient-to-br from-yellow-400 to-amber-600 shadow-2xl shadow-yellow-500/50"
               style={{ boxShadow: '0 0 60px rgba(251, 191, 36, 0.3)' }}></div>
        </div>
        <div className="absolute top-1/3 right-1/4 w-16 h-16 animate-float-delayed opacity-20">
          <div className="w-full h-full rounded-full bg-gradient-to-br from-amber-400 to-yellow-600 shadow-2xl shadow-amber-500/50"
               style={{ boxShadow: '0 0 60px rgba(245, 158, 11, 0.3)' }}></div>
        </div>
        <div className="absolute bottom-1/4 right-1/3 w-24 h-24 animate-float opacity-20" style={{ animationDelay: '1s' }}>
          <div className="w-full h-full rounded-full bg-gradient-to-br from-yellow-500 to-amber-700 shadow-2xl shadow-yellow-500/50"
               style={{ boxShadow: '0 0 60px rgba(234, 179, 8, 0.3)' }}></div>
        </div>
      </div>

      <div className={`relative z-10 min-h-screen flex flex-col transition-all duration-700 ${isTransitioning ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`}>
        {!showProducts ? (
          <div className="flex-1 flex flex-col items-center justify-center px-4 py-12">
            <div className={`text-center space-y-10 max-w-4xl mx-auto transition-all duration-700 ${isTransitioning ? 'opacity-0 scale-95' : 'opacity-100 scale-100 animate-in fade-in duration-1000'}`}>
              <div className="flex justify-center mb-12">
                <div className="relative">
                  <img
                    src="/logo.png"
                    alt="CardifyBNB Logo"
                    className="w-40 h-40 drop-shadow-2xl hover:scale-105 transition-transform duration-500"
                    style={{ filter: 'drop-shadow(0 0 40px rgba(251, 191, 36, 0.4))' }}
                  />
                  <div className="absolute inset-0 bg-yellow-400/20 rounded-full blur-3xl animate-pulse"></div>
                </div>
              </div>

              <h1 className="text-7xl md:text-8xl font-bold bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 bg-clip-text text-transparent animate-in slide-in-from-bottom duration-1000 tracking-tight">
                CardifyBNB
              </h1>

              <p className="text-xl md:text-2xl text-gray-400 max-w-2xl mx-auto animate-in slide-in-from-bottom duration-1000 delay-200 leading-relaxed font-medium">
                BNB-inspired crypto gifting — fast, secure, and effortlessly seamless.
              </p>

              <button
                onClick={handleShopNow}
                className="group relative inline-flex items-center gap-3 px-14 py-6 text-lg font-semibold text-black bg-gradient-to-r from-yellow-400 via-amber-400 to-yellow-500 rounded-full overflow-hidden transition-all duration-300 hover:scale-105 hover:shadow-2xl animate-in zoom-in duration-1000 delay-500 mt-8"
                style={{ boxShadow: '0 0 60px rgba(251, 191, 36, 0.4)' }}
              >
                <span className="relative z-10 flex items-center gap-3">
                  <ShoppingBag className="w-6 h-6" />
                  Shop Now
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-amber-500 to-yellow-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </button>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col">
            <header className="py-6 px-6 md:px-12 flex items-center justify-between border-b border-yellow-500/10 backdrop-blur-xl bg-black/20">
              <div className="flex items-center gap-4">
                <img
                  src="/logo.png"
                  alt="CardifyBNB"
                  className="w-12 h-12"
                  style={{ filter: 'drop-shadow(0 0 20px rgba(251, 191, 36, 0.4))' }}
                />
                <span className="text-2xl font-bold bg-gradient-to-r from-yellow-400 to-amber-400 bg-clip-text text-transparent">
                  CardifyBNB
                </span>
              </div>
              <button
                onClick={handleBackHome}
                className="flex items-center gap-2 px-6 py-3 text-sm font-medium text-gray-300 hover:text-yellow-400 bg-gray-800/50 hover:bg-gray-800 border border-gray-700 hover:border-yellow-500/50 rounded-full transition-all duration-300"
              >
                <ArrowLeft className="w-4 h-4" />
                Back
              </button>
            </header>

            <main className="flex-1 py-20 px-6 md:px-12">
              <div className="max-w-7xl mx-auto">
                <div className="text-center mb-16 animate-in fade-in slide-in-from-top duration-700">
                  <h2 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-yellow-400 to-amber-400 bg-clip-text text-transparent mb-4">
                    Premium Gift Cards
                  </h2>
                  <p className="text-gray-500 text-lg font-medium">
                    Buy with crypto, gift with confidence
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {giftCards.map((card, index) => (
                    <div
                      key={card.name}
                      className="group relative p-8 rounded-3xl bg-gradient-to-br from-gray-900/80 to-black/80 border border-gray-800 hover:border-yellow-500/30 transition-all duration-500 hover:scale-[1.02] backdrop-blur-xl animate-in fade-in zoom-in duration-700"
                      style={{
                        animationDelay: `${index * 100}ms`,
                        boxShadow: '0 10px 50px rgba(0, 0, 0, 0.5)'
                      }}
                    >
                      <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/0 to-amber-500/0 group-hover:from-yellow-500/5 group-hover:to-amber-500/5 rounded-3xl transition-all duration-500"></div>

                      <div className="relative z-10 flex flex-col items-center space-y-6">
                        <div className={`w-28 h-28 rounded-2xl bg-gradient-to-br ${card.color} flex items-center justify-center text-4xl font-bold shadow-2xl group-hover:scale-110 transition-transform duration-500`}
                             style={{ boxShadow: '0 20px 60px rgba(0, 0, 0, 0.6)' }}>
                          {card.name.charAt(0)}
                        </div>

                        <h3 className="text-2xl font-bold text-white">
                          {card.name}
                        </h3>

                        <p className="text-gray-500 text-sm font-medium">
                          Available Now
                        </p>

                        <button
                          onClick={handleBuyNow}
                          className="w-full mt-4 px-6 py-3 text-sm font-semibold text-black bg-gradient-to-r from-yellow-400 to-amber-400 rounded-full transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-yellow-500/20"
                        >
                          Buy Now
                        </button>
                      </div>

                      <div className="absolute inset-0 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                           style={{ boxShadow: '0 0 80px rgba(251, 191, 36, 0.15)' }}></div>
                    </div>
                  ))}
                </div>
              </div>
            </main>
          </div>
        )}

        <footer className="relative z-10 py-8 px-6 md:px-12 border-t border-yellow-500/10 backdrop-blur-xl bg-black/20">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
            <p className="text-gray-500 text-sm font-medium">
              © 2025 CardifyBNB. Fast, secure crypto gifting.
            </p>

            <div className="flex items-center gap-4">
              <a
                href="#"
                className="group flex items-center justify-center w-11 h-11 rounded-full bg-gray-900 border border-gray-800 hover:border-yellow-500/50 hover:bg-gray-800 hover:scale-110 transition-all duration-300"
              >
                <Send className="w-5 h-5 text-gray-400 group-hover:text-yellow-400 transition-colors duration-300" />
              </a>

              <a
                href="#"
                className="group flex items-center justify-center w-11 h-11 rounded-full bg-gray-900 border border-gray-800 hover:border-yellow-500/50 hover:bg-gray-800 hover:scale-110 transition-all duration-300"
              >
                <svg className="w-5 h-5 text-gray-400 group-hover:text-yellow-400 transition-colors duration-300" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
              </a>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;
